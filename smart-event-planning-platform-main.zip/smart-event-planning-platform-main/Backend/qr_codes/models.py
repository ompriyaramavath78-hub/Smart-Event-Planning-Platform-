"""
Database models.

Event         – minimal event record (already "existing" data in the
                real product; here it's the table the registration
                system was missing).
Registration  – one row per participant registration. This is the
                table that Feature 1 (payment) and Feature 2 (QR)
                extend, per the task's "extend, don't duplicate" rule.
"""
from datetime import datetime

from extensions import db


class Event(db.Model):
    __tablename__ = "events"

    id = db.Column(db.Integer, primary_key=True)
    event_id = db.Column(db.String(40), unique=True, nullable=False)  # e.g. EVT-101
    name = db.Column(db.String(200), nullable=False)
    date = db.Column(db.String(60), nullable=True)
    venue = db.Column(db.String(200), nullable=True)
    price_inr = db.Column(db.Integer, nullable=False, default=0)  # rupees (whole)

    registrations = db.relationship("Registration", backref="event", lazy=True)

    def to_dict(self):
        return {
            "event_id": self.event_id,
            "name": self.name,
            "date": self.date,
            "venue": self.venue,
            "price_inr": self.price_inr,
        }


class Registration(db.Model):
    __tablename__ = "registrations"

    id = db.Column(db.Integer, primary_key=True)
    registration_id = db.Column(db.String(40), unique=True, nullable=False)  # REG-1001
    event_id = db.Column(db.String(40), db.ForeignKey("events.event_id"), nullable=False)
    participant_id = db.Column(db.String(40), nullable=True)

    name = db.Column(db.String(200), nullable=False)
    email = db.Column(db.String(200), nullable=False)
    phone = db.Column(db.String(30), nullable=True)

    amount = db.Column(db.Integer, nullable=False)  # smallest currency unit (paise)
    currency = db.Column(db.String(10), nullable=False, default="INR")

    payment_status = db.Column(db.String(20), nullable=False, default="PENDING")
    # PENDING | SUCCESS | FAILED | CANCELLED

    razorpay_order_id = db.Column(db.String(80), nullable=True, index=True)
    razorpay_payment_id = db.Column(db.String(80), nullable=True)

    registration_token = db.Column(db.String(120), nullable=True, unique=True)
    qr_code_path = db.Column(db.String(300), nullable=True)

    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    def to_public_dict(self):
        """Safe subset for API responses — no tokens/secrets."""
        return {
            "registration_id": self.registration_id,
            "event_id": self.event_id,
            "name": self.name,
            "email": self.email,
            "payment_status": self.payment_status,
            "amount": self.amount,
            "currency": self.currency,
            "created_at": self.created_at.isoformat() if self.created_at else None,
        }
