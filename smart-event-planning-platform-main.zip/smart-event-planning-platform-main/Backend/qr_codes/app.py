"""
app.py
======
Main Flask application entry point.

The uploaded project shipped as a React (Vite) frontend only — there was
no existing backend, database, or registration system to extend. This
file is the minimal backend needed to run the app end to end: event
storage + a health/events endpoint, with the new payment + QR
functionality mounted from `payment_qr_backend.py` (kept separate, per
the requested project layout).

Run with:  python app.py
"""
import os

from dotenv import load_dotenv
from flask import Flask, jsonify
from flask_cors import CORS

load_dotenv()  # read RAZORPAY_*, SECRET_KEY, etc. from .env

from extensions import db  # noqa: E402  (must come after load_dotenv is fine either way)


def create_app():
    app = Flask(__name__)

    app.config["SECRET_KEY"] = os.environ.get("SECRET_KEY", "dev-secret-key-change-me")
    basedir = os.path.dirname(os.path.abspath(__file__))
    app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///" + os.path.join(basedir, "app.db")
    app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

    db.init_app(app)
    CORS(app)  # allow the Vite dev server (different port) to call this API

    # Import models so create_all() sees them, then register the new blueprint.
    from models import Event, Registration  # noqa: F401
    from payment_qr_backend import payment_qr_bp

    app.register_blueprint(payment_qr_bp)

    @app.route("/api/health")
    def health():
        return jsonify({"status": "ok"})

    @app.route("/api/events", methods=["GET"])
    def list_events():
        events = Event.query.all()
        return jsonify([e.to_dict() for e in events])

    @app.errorhandler(404)
    def not_found(_e):
        return jsonify({"error": "Not found."}), 404

    @app.errorhandler(500)
    def server_error(_e):
        return jsonify({"error": "Internal server error."}), 500

    with app.app_context():
        db.create_all()
        _seed_demo_event()

    return app


def _seed_demo_event():
    """Insert one demo event if the table is empty, so the registration
    flow has something to register for out of the box."""
    from models import Event

    if Event.query.first() is None:
        db.session.add(
            Event(
                event_id="EVT-101",
                name="Tech Fest 2026",
                date="15 March 2026",
                venue="Main Auditorium",
                price_inr=499,
            )
        )
        db.session.commit()


app = create_app()

if __name__ == "__main__":
    app.run(debug=True, port=5000)
