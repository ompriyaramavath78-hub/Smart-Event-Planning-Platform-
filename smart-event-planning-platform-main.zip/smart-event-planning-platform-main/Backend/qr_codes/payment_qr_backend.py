"""
payment_qr_backend.py
======================
ALL newly added functionality for:

  FEATURE 1 - Razorpay payment gateway integration
  FEATURE 2 - Registration QR code generation & validation

This is deliberately kept in its own file / Flask Blueprint so it can be
dropped into an existing Flask project without touching existing routes,
models, or app wiring. It only depends on `extensions.db` and
`models.Event` / `models.Registration`.

Nothing in this file hard-codes secrets. Razorpay credentials are read
from environment variables (see .env.example / PAYMENT_QR_SETUP.md).
"""
import hashlib
import hmac
import os
import secrets
import uuid
from datetime import datetime

import qrcode
import razorpay
from flask import Blueprint, current_app, jsonify, request, send_from_directory

from extensions import db
from models import Event, Registration

payment_qr_bp = Blueprint("payment_qr", __name__)

QR_CODE_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "qr_codes")
os.makedirs(QR_CODE_DIR, exist_ok=True)


# ---------------------------------------------------------------------------
# Razorpay client
# ---------------------------------------------------------------------------
def _get_razorpay_client():
    """
    Build a Razorpay client from environment variables.

    Raises a clear, catchable error (instead of a stack trace) if the
    credentials are missing, per the "fail gracefully" requirement.
    """
    key_id = os.environ.get("RAZORPAY_KEY_ID")
    key_secret = os.environ.get("RAZORPAY_KEY_SECRET")
    if not key_id or not key_secret:
        raise RuntimeError(
            "Razorpay credentials are not configured. Set RAZORPAY_KEY_ID "
            "and RAZORPAY_KEY_SECRET in your .env file (see .env.example)."
        )
    return razorpay.Client(auth=(key_id, key_secret))


# ---------------------------------------------------------------------------
# ID / token helpers
# ---------------------------------------------------------------------------
def _generate_registration_id():
    """REG-<8 hex chars>, checked for uniqueness."""
    while True:
        candidate = f"REG-{uuid.uuid4().hex[:8].upper()}"
        if not Registration.query.filter_by(registration_id=candidate).first():
            return candidate


def _generate_registration_token(registration_id: str) -> str:
    """
    Secure, unguessable token for this registration.

    Combines a random component with an HMAC over the registration_id
    (keyed by the Flask SECRET_KEY) so a token can later be verified as
    genuinely issued by this server, not just "looks like a token".
    No sensitive data (password, payment secret, etc.) is embedded.
    """
    random_part = secrets.token_urlsafe(16)
    secret_key = current_app.config["SECRET_KEY"].encode("utf-8")
    signature = hmac.new(
        secret_key, f"{registration_id}:{random_part}".encode("utf-8"), hashlib.sha256
    ).hexdigest()[:16]
    return f"{random_part}.{signature}"


def _token_is_valid(registration: Registration, token: str) -> bool:
    if not registration.registration_token:
        return False
    return hmac.compare_digest(registration.registration_token, token)


# ---------------------------------------------------------------------------
# QR helpers
# ---------------------------------------------------------------------------
def _build_qr_payload(registration: Registration) -> str:
    """
    Plain-text QR payload. Contains only what's needed to look the
    registration up and prove it's genuine — never passwords, payment
    secrets, or DB credentials.
    """
    return (
        f"REGISTRATION_ID={registration.registration_id}\n"
        f"EVENT_ID={registration.event_id}\n"
        f"TOKEN={registration.registration_token}"
    )


def _generate_qr_code(registration: Registration) -> str:
    """Generate and save a QR image for a registration. Returns the file path."""
    payload = _build_qr_payload(registration)
    img = qrcode.make(payload)
    filename = f"{registration.registration_id}.png"
    filepath = os.path.join(QR_CODE_DIR, filename)
    img.save(filepath)
    return filepath


# ---------------------------------------------------------------------------
# ROUTES
# ---------------------------------------------------------------------------

@payment_qr_bp.route("/api/payment/create-order", methods=["POST"])
def create_order():
    """
    Validate participant + event details, create a Registration record
    (PENDING), then create a matching Razorpay order.

    Body JSON:
        { "event_id": "EVT-101", "name": "...", "email": "...", "phone": "..." }
    """
    data = request.get_json(silent=True) or {}
    event_id = (data.get("event_id") or "").strip()
    name = (data.get("name") or "").strip()
    email = (data.get("email") or "").strip()
    phone = (data.get("phone") or "").strip()

    if not event_id or not name or not email:
        return jsonify({"error": "event_id, name and email are required."}), 400

    event = Event.query.filter_by(id=event_id).first()
    if not event:
        return jsonify({"error": f"Event '{event_id}' not found."}), 404

    if event.price_inr <= 0:
        return jsonify({"error": "Invalid event amount."}), 400

    amount_paise = event.price_inr * 100  # Razorpay works in the smallest currency unit
    currency = "INR"

    try:
        client = _get_razorpay_client()
    except RuntimeError as exc:
        return jsonify({"error": str(exc)}), 500

    registration_id = _generate_registration_id()

    registration = Registration(
        registration_id=registration_id,
        event_id=event.event_id,
        name=name,
        email=email,
        phone=phone,
        amount=amount_paise,
        currency=currency,
        payment_status="PENDING",
    )
    db.session.add(registration)
    db.session.commit()

    try:
        order = client.order.create(
            {
                "amount": amount_paise,
                "currency": currency,
                "receipt": registration_id,
                "notes": {"registration_id": registration_id, "event_id": event.event_id},
            }
        )
    except Exception as exc:  # noqa: BLE001 - surface a clean error, not a stack trace
        registration.payment_status = "FAILED"
        db.session.commit()
        return jsonify({"error": f"Could not create payment order: {exc}"}), 502

    registration.razorpay_order_id = order["id"]
    db.session.commit()

    return jsonify(
        {
            "registration_id": registration.registration_id,
            "order_id": order["id"],
            "amount": amount_paise,
            "currency": currency,
            "key_id": os.environ.get("RAZORPAY_KEY_ID"),
            "event_name": event.name,
        }
    ), 201


@payment_qr_bp.route("/api/payment/verify", methods=["POST"])
def verify_payment():
    """
    Verify a Razorpay payment signature and, on success, mark the
    registration SUCCESS, generate its token + QR code.

    Body JSON:
        {
          "registration_id": "REG-...",
          "razorpay_order_id": "...",
          "razorpay_payment_id": "...",
          "razorpay_signature": "..."
        }
    """
    data = request.get_json(silent=True) or {}
    registration_id = data.get("registration_id")
    razorpay_order_id = data.get("razorpay_order_id")
    razorpay_payment_id = data.get("razorpay_payment_id")
    razorpay_signature = data.get("razorpay_signature")

    if not all([registration_id, razorpay_order_id, razorpay_payment_id, razorpay_signature]):
        return jsonify({"error": "Missing payment verification fields."}), 400

    registration = Registration.query.filter_by(registration_id=registration_id).first()
    if not registration:
        return jsonify({"error": "Registration not found."}), 404

    # Duplicate-payment protection: already confirmed, don't re-process.
    if registration.payment_status == "SUCCESS":
        return jsonify(
            {
                "status": "SUCCESS",
                "message": "Payment already verified for this registration.",
                "registration": registration.to_public_dict(),
            }
        ), 200

    if registration.razorpay_order_id != razorpay_order_id:
        return jsonify({"error": "Order ID does not match this registration."}), 400

    try:
        client = _get_razorpay_client()
        client.utility.verify_payment_signature(
            {
                "razorpay_order_id": razorpay_order_id,
                "razorpay_payment_id": razorpay_payment_id,
                "razorpay_signature": razorpay_signature,
            }
        )
    except RuntimeError as exc:
        return jsonify({"error": str(exc)}), 500
    except razorpay.errors.SignatureVerificationError:
        registration.payment_status = "FAILED"
        db.session.commit()
        return jsonify({"error": "Invalid payment signature.", "status": "FAILED"}), 400

    # Signature verified -> payment is genuinely successful.
    registration.payment_status = "SUCCESS"
    registration.razorpay_payment_id = razorpay_payment_id
    registration.registration_token = _generate_registration_token(registration_id)
    db.session.commit()

    try:
        qr_path = _generate_qr_code(registration)
        registration.qr_code_path = qr_path
        db.session.commit()
    except Exception as exc:  # noqa: BLE001
        # Payment already succeeded; QR failure shouldn't roll that back.
        return jsonify(
            {
                "status": "SUCCESS",
                "warning": f"Payment verified but QR generation failed: {exc}",
                "registration": registration.to_public_dict(),
            }
        ), 200

    return jsonify(
        {
            "status": "SUCCESS",
            "registration": registration.to_public_dict(),
            "qr_url": f"/api/registration/{registration_id}/qr",
        }
    ), 200


@payment_qr_bp.route("/api/payment/cancel", methods=["POST"])
def cancel_payment():
    """Called by the frontend when the user closes/cancels the Razorpay checkout."""
    data = request.get_json(silent=True) or {}
    registration_id = data.get("registration_id")
    registration = Registration.query.filter_by(registration_id=registration_id).first()
    if not registration:
        return jsonify({"error": "Registration not found."}), 404

    if registration.payment_status == "PENDING":
        registration.payment_status = "CANCELLED"
        db.session.commit()

    return jsonify({"status": registration.payment_status}), 200


@payment_qr_bp.route("/api/payment/status/<registration_id>", methods=["GET"])
def payment_status(registration_id):
    registration = Registration.query.filter_by(registration_id=registration_id).first()
    if not registration:
        return jsonify({"error": "Registration not found."}), 404
    return jsonify(registration.to_public_dict()), 200


@payment_qr_bp.route("/api/registration/<registration_id>/qr", methods=["GET"])
def get_qr_code(registration_id):
    """Serve the saved QR code image for a successfully paid registration."""
    registration = Registration.query.filter_by(registration_id=registration_id).first()
    if not registration:
        return jsonify({"error": "Registration not found."}), 404
    if registration.payment_status != "SUCCESS" or not registration.qr_code_path:
        return jsonify({"error": "QR code not available for this registration."}), 400

    directory, filename = os.path.split(registration.qr_code_path)
    return send_from_directory(directory, filename, mimetype="image/png")


@payment_qr_bp.route("/api/registration/qr/validate", methods=["POST"])
def validate_qr():
    """
    Validate a scanned QR code.

    Body JSON, either:
        { "registration_id": "REG-...", "token": "..." }
    or the raw text a QR scanner read straight off the code:
        { "raw_text": "REGISTRATION_ID=REG-...\\nEVENT_ID=EVT-...\\nTOKEN=..." }
    """
    data = request.get_json(silent=True) or {}
    registration_id = data.get("registration_id")
    token = data.get("token")

    if not registration_id and not token and data.get("raw_text"):
        parsed = {}
        for line in data["raw_text"].splitlines():
            if "=" in line:
                key, _, value = line.partition("=")
                parsed[key.strip()] = value.strip()
        registration_id = parsed.get("REGISTRATION_ID")
        token = parsed.get("TOKEN")

    if not registration_id or not token:
        return jsonify({"valid": False, "error": "registration_id and token are required."}), 400

    registration = Registration.query.filter_by(registration_id=registration_id).first()
    if not registration:
        return jsonify({"valid": False, "error": "Registration not found."}), 404

    if not _token_is_valid(registration, token):
        return jsonify({"valid": False, "error": "Invalid or forged token."}), 400

    if registration.payment_status != "SUCCESS":
        return jsonify(
            {
                "valid": False,
                "registration_id": registration.registration_id,
                "event_id": registration.event_id,
                "payment_status": registration.payment_status,
            }
        ), 200

    event = Event.query.filter_by(event_id=registration.event_id).first()
    if not event:
        return jsonify({"valid": False, "error": "Associated event no longer exists."}), 404

    return jsonify(
        {
            "valid": True,
            "registration_id": registration.registration_id,
            "event_id": registration.event_id,
            "event_name": event.name,
            "payment_status": registration.payment_status,
            "name": registration.name,
        }
    ), 200
