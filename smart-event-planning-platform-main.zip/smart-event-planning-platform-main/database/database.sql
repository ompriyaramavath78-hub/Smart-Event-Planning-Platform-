PRAGMA foreign_keys = ON;

CREATE TABLE events (
    event_id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    event_date DATE NOT NULL,
    event_time TIME NOT NULL,
    venue_id INTEGER,
    status TEXT NOT NULL DEFAULT 'Planning',
    budget REAL,
    FOREIGN KEY (venue_id) REFERENCES venues(venue_id)
);

CREATE TABLE venues (
    venue_id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL
);

CREATE TABLE resources (
    resource_id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    quantity INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE event_resources (
    event_id INTEGER NOT NULL,
    resource_id INTEGER NOT NULL,
    quantity INTEGER NOT NULL,
    PRIMARY KEY (event_id, resource_id),
    FOREIGN KEY (event_id) REFERENCES events(event_id),
    FOREIGN KEY (resource_id) REFERENCES resources(resource_id)
);

CREATE TABLE registrations (
    registration_id INTEGER PRIMARY KEY AUTOINCREMENT,
    event_id INTEGER NOT NULL,
    name TEXT NOT NULL,
    email TEXT NOT NULL,
    phone TEXT,
    ticket_id TEXT NOT NULL UNIQUE,
    status TEXT NOT NULL DEFAULT 'Registered',
    UNIQUE (event_id, email),
    FOREIGN KEY (event_id) REFERENCES events(event_id)
);

CREATE TABLE vendors (
    vendor_id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    services TEXT NOT NULL
);

CREATE TABLE event_vendors (
    event_vendor_id INTEGER PRIMARY KEY AUTOINCREMENT,
    event_id INTEGER NOT NULL,
    vendor_id INTEGER NOT NULL,
    selected_service TEXT NOT NULL,
    FOREIGN KEY (event_id) REFERENCES events(event_id),
    FOREIGN KEY (vendor_id) REFERENCES vendors(vendor_id)
);